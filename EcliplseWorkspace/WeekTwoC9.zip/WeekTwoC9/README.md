This is the tutorial two for our advance programming technologies module
we are to create a simple online form that takes input and stores it in a mysql database using xampp, apache and tomcat